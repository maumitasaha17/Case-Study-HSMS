package com.cg.demo.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.demo.entity.Finance;

@Repository
public interface IFinanceRepository extends JpaRepository<Finance, Integer> {
/*
	// Custom Methods
	// find finance based on patient name and display in asc order
	List<Finance> findByFinanceIdOrderByPatientName(int financeId);

	// Custom Queries
	// find patient based on name
	@Query("select f from Finance f where f.patientName=:n") // select f from finance table where name =:n
	public Finance getFinanceByName(@Param("n") String patientName); // binding n with patient name

	// Find patient based on name and id
	// Passing 2 values
	@Query("select f from Finance f where f.patientName=:n and f.patientId=:i")
	public Finance getFinanceByNameAndId(@Param("n") String patientName, @Param("i") int patientId);

	// Native QUERIES
	@Query("select f from Finance f where f.patientName=:n or f.patientId=:i")
	public Finance getFinanceByNameOrId(@Param("n") String patientName, @Param("i") int patientId);
*/
}