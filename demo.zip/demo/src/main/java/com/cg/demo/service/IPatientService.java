package com.cg.demo.service;

import java.util.List;

import com.cg.demo.entity.Patient;

public interface IPatientService {
 	
	Patient findByPatientId(int id);
	List<Patient> findAll();
	Patient deleteByPatientId(int id);
	Patient save(Patient patient);
	Patient updateByPatientId(int id);
	
	
	// custom methods
	// find by name
	Patient findByPatientName(String name);
	Patient delete(Patient patient);
}