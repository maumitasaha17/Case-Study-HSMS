package com.cg.demo.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.entity.Finance;
import com.cg.demo.repository.IFinanceRepository;

@Service
public class FinanceServiceImpl implements IFinanceService {

	@Autowired
	IFinanceRepository financeRepo;

	// save
	@Override
	public Finance save(Finance finance) {
		return financeRepo.save(finance);
	}

	// findAllFinanceDetails
	@Override
	public List<Finance> findAllFinanceDetails() {
		return financeRepo.findAll();
	}

	// findByPatientId
	@Override
	public Finance findByPatientId(int patientId) {
		// Finance fin = financeService.findById(id).get();
		Optional<Finance> opt = financeRepo.findById(patientId);

		if (!opt.isPresent()) {
			return null;
		}
		return opt.get();
	}

	// deleteFinanceByPatientId
	@Override
	public Finance deleteFinanceByPatientId(int patientId) {
		Optional<Finance> opt = financeRepo.findById(patientId);
		if (!opt.isPresent()) {
			return null;
		}
		Finance fin = opt.get();
		financeRepo.deleteById(patientId);
		return fin;
	}

	// update
	@Override
	public Finance update(Finance finance) {
		Optional<Finance> opt = financeRepo.findById(10);
		finance.setPatientId(finance.getPatientId());
		return financeRepo.save(finance);
	}
	
	
	/*
	public Finance update(int patientId) {
		Optional<Finance> opt = financeRepo.findById(finance.getPatientId());
		if (!opt.isPresent()) {
			return null;
		}
		Finance fin = opt.get();
		fin.setPatientId(fin.getPatientId());
		fin.setPatientName(finance.getPatientName());
		fin.setRegistrationFee(finance.getRegistrationFee());
		fin.setDoctorFee(finance.getDoctorFee());
		fin.setMedicinesAmount(finance.getMedicinesAmount());
		fin.setTotalFee(finance.getTotalFee());
		fin.setFinanceId(finance.getFinanceId());
		return financeRepo.save(fin);
	}*/
/*
	public Finance update(int patientId) {
		Optional<Finance> opt = financeRepo.findById(patientId);
		if (!opt.isPresent()) {
			return null;
		}
		return opt.get();
		*/

	/*
	 * //updateFinanceByFinanceId
	 * 
	 * @Override public Finance updateFinanceByFinanceId(int financeId) { Finance
	 * fin = financeRepo.findById(finance.getFinanceId()).get();
	 * fin.setFinanceId(fin.getFinanceId()); return financeRepo.save(fin); }
	 * 
	 * 
	 * // custom method // findByFinanceIdOrderByPatientName
	 * 
	 * @Override public List<Finance> findByFinanceIdOrderByPatientName(int
	 * financeId) { // Finance f = //
	 * financeService.findByFinanceOrderByPatientName(patientName).get(); // return
	 * financeRepo.findByFinanceOrderByPatientName(patientName); return
	 * financeRepo.findByFinanceIdOrderByPatientName(financeId); }
	 */

	
	}
