package com.cg.demo.exception;

/*
 * 1.Create error message for pojo class
 * 2.create custom exception class
 * 3.throw the exception from the controller
 * 4.@ExceptionHandler - handle exceptions
 * 
 */
public class FinanceNotFoundException extends RuntimeException {

	public FinanceNotFoundException(String message, Throwable cause) {
		super(message, cause);

	}

	public FinanceNotFoundException(String message) {
		super(message);

	}

	public FinanceNotFoundException(Throwable cause) {
		super(cause);

	}

}