package com.cg.demo.service;

import java.util.List;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.demo.entity.Patient;
import com.cg.demo.repository.IPatientRepository;

import com.cg.demo.entity.Patient;
//import com.cg.demo.entity.Address;

@Service
public  class PatientServiceImpl implements IPatientService {


	@Autowired
	IPatientRepository patientRepo;

	@Override
	public Patient findByPatientId(int id) {
		
		Optional<Patient> patient = patientRepo.findById(id);
		if(!patient.isPresent()) {
			return null;
		}
		return patient.get();
	}

	
	@Override
	public List<Patient> findAll() {
		return patientRepo.findAll();
	}
	
	@Override
	public Patient save(Patient patient) {
		return patientRepo.save(patient);
	}
	
	
	@Override
	public Patient findByPatientName(String name) {
		return  patientRepo.findByPatientName(name);
	}


	@Override
	public Patient deleteByPatientId(int id) {
	  Optional<Patient> patient = patientRepo.findById(id);
	if(!patient.isPresent()) {
		return null;
	}
	patientRepo.deleteById(id);
	return patient.get();
}


	@Override
	public Patient delete(Patient patient) {
		patientRepo.delete(patient);
		return patient;
	}


	@Override
	public Patient updateByPatientId(int id) {
	  Optional<Patient> patient = patientRepo.findById(id);
		if(!patient.isPresent()) {
			return null;
		}
		return patient.get();
	}

	

}