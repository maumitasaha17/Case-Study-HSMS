package com.cg.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.demo.entity.Finance;
import com.cg.demo.exception.FinanceNotFoundException;
import com.cg.demo.service.IFinanceService;

@RestController
@CrossOrigin
public class FinanceController {

	@Autowired
	IFinanceService financeService;

	// WRITE
	// save
	@PostMapping("/finance")
	public Finance save(@RequestBody Finance finance) {
		return financeService.save(finance);
	}

	// Read
	// findAllFinanceDetails
	@GetMapping("/finance")
	public ResponseEntity<List<Finance>> findAllFinanceDetails() {
		return new ResponseEntity<List<Finance>>(financeService.findAllFinanceDetails(), HttpStatus.OK);
	}
	/*
	public List<Finance> findAllFinanceDetails() {
		return financeService.findAllFinanceDetails();
	}
	*/

	// findByPatientId
	@GetMapping("/finance/id/{patientid}")
	public Finance findByPatientId(@PathVariable("patientid") int patientId) {
		if (financeService.findByPatientId(patientId) == null) {
			throw new FinanceNotFoundException("FINANCE NOT FOUND WITH THIS ID: " + patientId);
		}
		return financeService.findByPatientId(patientId);
	}

	// DELETE
	// deleteFinanceByPatientId
	@DeleteMapping("/finance/{patientid}")
	public Finance deleteFinanceByPatientId(@PathVariable("patientid") int patientId) {
		if (financeService.findByPatientId(patientId) == null) {
			throw new FinanceNotFoundException("Finance not found with this id to delete");
		}
		return financeService.deleteFinanceByPatientId(patientId);
	}

	// UPDATE
	// Updating specific property
	// updateFinance
	@PutMapping("/finance/{patientid}")
	public Finance update(@PathVariable("patientid") int patientId, @RequestBody Finance finance) {
		if (financeService.update(finance) == null) {
			throw new FinanceNotFoundException("Finance not found with this id to update");
		}
		return financeService.update(finance);
	}

	/*
	 * @PatchMapping("/finance/{financeid}") public Finance
	 * updateFinanceByFinanceId(@PathVariable("financeid") int financeId, @RequestBody
	 * Finance finance) { return financeService.updateFinanceByFinanceId(financeId);
	 * }
	 * 
	 * 
	 * // custom method // findByFinanceOrderByPatientName
	 * 
	 * @GetMapping("/finance/financeId/{financeId}") public List<Finance>
	 * findByFinanceIdOrderByPatientName(@PathVariable("name") int financeId) {
	 * return financeService.findByFinanceIdOrderByPatientName(financeId); }
	 */

	

}
