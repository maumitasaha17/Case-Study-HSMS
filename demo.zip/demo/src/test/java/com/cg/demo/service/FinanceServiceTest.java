package com.cg.demo.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.demo.entity.Finance;

@SpringBootTest
class FinanceServiceTest {

	@Autowired
	IFinanceService financeService;

	// save
	@Test
	public void testSave() {
		Finance fin = new Finance(1008, "Deepa", 400, 1000, 670, 2070, 1008);
		
		Finance persistedFin = financeService.save(fin);

		assertEquals(1008, persistedFin.getPatientId()); 
		  assertEquals("Deepa",persistedFin.getPatientName()); 
		  assertEquals(400,persistedFin.getRegistrationFee()); 
		  assertEquals(1000,persistedFin.getDoctorFee()); 
		  assertEquals(670,persistedFin.getMedicinesAmount()); 
		  assertEquals(2070,persistedFin.getTotalFee()); 
		  assertEquals(1008, persistedFin.getFinanceId());
	}

	// findAllFinanceDetails
	@Test
	public void testFindAllFinanceDetails() {
		List<Finance> fin = financeService.findAllFinanceDetails();
		assertEquals(6, fin.size());
	}

	// findByPatientId
	@Test
	public void testFindByPatientId() {
		Finance fin = financeService.findByPatientId(1002);
		System.out.println(fin);
		assertEquals("Soham", fin.getPatientName());
	}

	// deleteFinanceByPatientId
	@Test
	public void testDeleteFinanceByPatientId() {
	//	Finance fin = financeService.deleteFinanceByPatientId(1003);
	//	assertEquals("1003", fin.getPatientId());
	
	
	  Finance fin = new Finance(1008, "Deepa", 400, 1000, 670, 2070, 1008);
	  Finance persistedFin = financeService.deleteFinanceByPatientId(1008);
	  
	  assertEquals(1008, persistedFin.getPatientId()); 
	  assertEquals("Deepa",persistedFin.getPatientName()); 
	  assertEquals(400,persistedFin.getRegistrationFee()); 
	  assertEquals(1000,persistedFin.getDoctorFee()); 
	  assertEquals(670,persistedFin.getMedicinesAmount()); 
	  assertEquals(2070,persistedFin.getTotalFee()); 
	  assertEquals(1008, persistedFin.getFinanceId());
	 }
	
	// update
	@Test
	public void testUpdate() {
		Finance fin = new Finance();
		fin.setPatientId(1004);
		fin.setPatientName("Reeti");
		Finance updfin = financeService.update(fin);
		assertEquals(1004, updfin.getPatientId());
	}
	/*
	 * Finance finance = new Finance(1009, "Ranbir", 400, 1000, 300, 1700, 9);
	 * Finance persistedFin = financeService.update(finance);
	 * 
	 * assertEquals(1009, persistedFin.getPatientId()); assertEquals("Ranbir",
	 * persistedFin.getPatientName()); assertEquals(400,
	 * persistedFin.getRegistrationFee()); assertEquals(1000,
	 * persistedFin.getDoctorFee()); assertEquals(300,
	 * persistedFin.getMedicinesAmount()); assertEquals(1700,
	 * persistedFin.getTotalFee()); assertEquals(9, persistedFin.getFinanceId()); }
	 */

}