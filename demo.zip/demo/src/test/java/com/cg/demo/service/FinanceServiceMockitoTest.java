package com.cg.demo.service;

import static org.junit.jupiter.api.Assertions.assertEquals;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cg.demo.entity.Finance;
import com.cg.demo.repository.IFinanceRepository;

@ExtendWith(SpringExtension.class)
public class FinanceServiceMockitoTest {
	// Mock - imitating
	// DB -
	// Product -

	// @InjectMock - injects FinanceService and inject dependent classes/interfaces
	// that are annotated with @Mock
	@InjectMocks
	FinanceServiceImpl financeService;

	// @MockBean - injecting external services

	@MockBean
	IFinanceRepository financeRepo;

	// Initialization of mock objects
	@BeforeEach
	void init() {
		MockitoAnnotations.openMocks(this);
	}

	// save
	@Test
	void testSave() {
		Finance fin = new Finance(1001, "Raghav", 400, 1000, 1500, 2900, 1001);
		Mockito.when(financeRepo.save(fin)).thenReturn(fin);

		Finance persistedFin = financeService.save(fin);

		assertEquals(1001, persistedFin.getPatientId());
		assertEquals("Raghav", persistedFin.getPatientName());
		assertEquals(400, persistedFin.getRegistrationFee());
		assertEquals(1000, persistedFin.getDoctorFee());
		assertEquals(1500, persistedFin.getMedicinesAmount());
		assertEquals(2900, persistedFin.getTotalFee());
		assertEquals(1001, persistedFin.getFinanceId());
	}

	// findAllFinanceDetails
	@Test
	void testFindAllFinanceDetails() {
		Finance f1 = new Finance(1001, "Raghav", 400, 1000, 1500, 2900, 1001);
		Finance f2 = new Finance(1002, "Soham", 400, 1000, 2000, 3400, 1002);
		Finance f3 = new Finance(1003, "Ahmed", 400, 1000, 1350, 2750, 1003);
		Finance f4 = new Finance(1004, "Reeti", 400, 1000, 750, 2250, 1004);
		Finance f5 = new Finance(1005, "Ramesh", 400, 1000, 900, 2300, 1005);
		Finance f6 = new Finance(1006, "Ramya", 400, 1000, 1000, 2400, 1006);
		Finance f7 = new Finance(1007, "Vinod", 400, 1000, 1970, 3370, 1007);
		Finance f8 = new Finance(1008, "Deepa", 400, 1000, 670, 2070, 1008);

		List<Finance> financeList = new ArrayList<>();
		financeList.add(f1);
		financeList.add(f2);
		financeList.add(f3);
		financeList.add(f4);
		financeList.add(f5);
		financeList.add(f6);
		financeList.add(f7);
		financeList.add(f8);
		Mockito.when(financeRepo.findAll()).thenReturn(financeList);
		List<Finance> fin = financeService.findAllFinanceDetails();
		assertEquals(8, fin.size());
	}

	// findByPatientId
	@Test
	void testFindByPatientId() {
		Finance fin = new Finance(1002, "Soham", 400, 1000, 2000, 3400, 1002);

		Mockito.when(financeRepo.findById(1002)).thenReturn(Optional.of(fin));
		Finance persistedFin = financeService.findByPatientId(1002);

		assertEquals(1002, persistedFin.getPatientId());
		assertEquals("Soham", persistedFin.getPatientName());
		assertEquals(400, persistedFin.getRegistrationFee());
		assertEquals(1000, persistedFin.getDoctorFee());
		assertEquals(2000, persistedFin.getMedicinesAmount());
		assertEquals(3400, persistedFin.getTotalFee());
		assertEquals(1002, persistedFin.getFinanceId());
	}

	// deleteFinanceByPatientId
	@Test
	void testDeleteFinanceByPatientId() {
		Finance fin = new Finance(1003, "Ahmed", 400, 1000, 1350, 2750, 1003);

		Mockito.when(financeRepo.findById(1003)).thenReturn(Optional.of(fin));
		financeRepo.deleteById(1003);

		Finance persistedFin = financeService.deleteFinanceByPatientId(1003);

		assertEquals(1003, persistedFin.getPatientId());
		assertEquals("Ahmed", persistedFin.getPatientName());
		assertEquals(400, persistedFin.getRegistrationFee());
		assertEquals(1000, persistedFin.getDoctorFee());
		assertEquals(1350, persistedFin.getMedicinesAmount());
		assertEquals(2750, persistedFin.getTotalFee());
		assertEquals(1003, persistedFin.getFinanceId());
	}

	// update
	@Test
	void testUpdate() {
		Finance fin = new Finance(1004, "Reeti", 400, 1000, 750, 2150, 1004);

		Mockito.when(financeRepo.findById(1004)).thenReturn(Optional.of(fin));
		Mockito.when(financeRepo.save(fin)).thenReturn(fin);

		Finance persistedFin = financeService.update(fin);

		assertEquals(1004, persistedFin.getPatientId());
		assertEquals("Reeti", persistedFin.getPatientName());
		assertEquals(400, persistedFin.getRegistrationFee());
		assertEquals(1000, persistedFin.getDoctorFee());
		assertEquals(750, persistedFin.getMedicinesAmount());
		assertEquals(2150, persistedFin.getTotalFee());
		assertEquals(1004, persistedFin.getFinanceId());
	}

}