package com.cg.hsms;

import org.apache.logging.log4j.LogManager;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
@SpringBootApplication

public class HsmsApplication {

	org.apache.logging.log4j.Logger logger = LogManager.getLogger();

	public static void main(String[] args) {
		SpringApplication.run(HsmsApplication.class, args);
	}

	// Enable Swagger
	@Bean
	public Docket productApi() {
		return new Docket(DocumentationType.SWAGGER_2).select().paths(PathSelectors.any()).build();
	}

	/*
	 * // Command Line Runner
	 * 
	 * @Bean CommandLineRunner cmdLineRunner(IFinanceRepository financeService) {
	 * return args -> {
	 * 
	 * logger.info(financeService.findByFinanceIdOrderByPatientName(1008));
	 * logger.info(financeService.getFinanceByName("Ramya"));
	 * 
	 * // Custom Query logger.info(financeService.getFinanceByNameAndId("Soham",
	 * 1002));
	 * 
	 * // Native Query logger.info(financeService.getFinanceByNameOrId("Ahmed",
	 * 1003));
	 * 
	 * };
	 */

}
