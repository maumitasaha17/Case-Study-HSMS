package com.cg.hsms.service;

import java.util.List;

import com.cg.hsms.entity.Finance;

public interface IFinanceService {

	// save
	public Finance save(Finance finance);

	// findAllFinanceDetails
	public List<Finance> findAllFinanceDetails();

	// findByPatientId
	public Finance findByPatientId(int patientId);

	// deleteFinanceByFinanceId
	public Finance deleteFinanceByPatientId(int patientId);

	// update
	public Finance update(Finance finance);

	
	
	/*
	 * //updateFinanceByFinanceId Finance updateFinanceByFinanceId(int financeId);
	 * 
	 * 
	 * // custom methods // find finance based on patient name and display in asc
	 * order List<Finance> findByFinanceIdOrderByPatientName(int financeId);
	 */
}
